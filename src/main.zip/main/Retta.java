package main;

import java.awt.*;

public class Retta extends Funzione {
    double m;
    double q;

    public Retta( float m, double q ) {
        this.m = m;
        this.q = q;
    }

    @Override
    public double f( double x ) {
        return m * x + q;
    }

    @Override
    public Color getColor() {
        return Color.green;
    }
}
