package main;

import java.awt.*;

public interface Rappresentabile {

    double[] plot( double x );

    Color getColor();
}
