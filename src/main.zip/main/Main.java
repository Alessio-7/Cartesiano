package main;

import preferenze.PreferenzeGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class Main {

    PreferenzeGUI gui;

    private Main() {
        gui = new PreferenzeGUI( PreferenzeGUI.TEMA_SCURO );
        PianoCartesiano p = new PianoCartesiano();

        p.addRappresentabile( new Retta( 0, 0 ) );
        p.addRappresentabile( new Sin( 100, .1 ) );

        gui.creaFinestra( "Cartesiano", p, true );
    }

    public static void main( String[] args ) {
        new Main();
    }

    private class PianoCartesiano extends JPanel {

        private final ArrayList<Rappresentabile> rap;
        double scale = 1;

        public PianoCartesiano() {
            rap = new ArrayList<>();
        }

        public void addRappresentabile( Rappresentabile r ) {
            rap.add( r );
        }

        @Override
        protected void paintComponent( Graphics g1 ) {
            Graphics2D g = (Graphics2D) g1;
            g.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON );
            g.setRenderingHint( RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY );

            BufferedImage img = new BufferedImage( getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB );
            int w = (getWidth() / 2);
            int h = (getHeight() / 2);


            for( double x = -w; x < w; x += 0.1 ) {
                for( Rappresentabile r : rap ) {
                    for( double y : r.plot( x ) ) {
                        System.out.println( y + " = " + x );
                        try {
                            img.setRGB( toPixel( x, w ), toPixel( y, h ), r.getColor().getRGB() );
                        } catch( Exception e ) {
                        }
                    }
                }
            }

            g.drawImage( img, 0, 0, null );
        }

        int toPixel( double x, int ref ) {
            return (int) (ref - (x) / scale);
        }
    }
}
