package main;

import java.awt.*;

public class Circonferenza implements Rappresentabile {

    double alfa;
    double beta;
    double r2;

    public Circonferenza( double alfa, double beta, double r ) {
        this.alfa = alfa;
        this.beta = beta;
        this.r2 = Math.pow( r, 2 );
    }


    @Override
    public double[] plot( double x ) {

        double a = -alfa * 2d;
        double b = -beta * 2d;
        double c = Math.pow( alfa, 2 ) + Math.pow( beta, 2 ) - r2;
        return new double[0];
    }

    @Override
    public Color getColor() {
        return Color.red;
    }
}
