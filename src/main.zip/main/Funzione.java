package main;

public abstract class Funzione implements Rappresentabile {

    public abstract double f( double x );

    @Override
    public double[] plot( double x ) {
        return new double[]{f( x )};
    }
}
