package main;

import java.awt.*;

public class Sin extends Funzione {

    double ampiezza;
    double frequenza;

    public Sin( double ampiezza, double periodo ) {
        this.ampiezza = ampiezza;
        this.frequenza = periodo;
    }

    @Override
    public double f( double x ) {
        return ampiezza * Math.sin( x * frequenza );
    }

    @Override
    public Color getColor() {
        return Color.cyan;
    }
}
